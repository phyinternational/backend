# Creates application.zip excluding node_modules, .git, .vercel, .env, and existing application.zip
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\create_application_zip.ps1

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
# project root is parent of scripts folder
$root = Resolve-Path (Join-Path $scriptDir '..')
Set-Location $root

$exclude = @('node_modules', '.git', '.vercel', '.env', 'application.zip')
Write-Output "Excluding: $($exclude -join ', ')"

# Get top-level items to include
$items = Get-ChildItem -Force | Where-Object { $exclude -notcontains $_.Name }

if (-not $items -or $items.Count -eq 0) {
    Write-Output 'NO_ITEMS_TO_ZIP'
    exit 0
}

# Build array of full paths
$paths = $items | ForEach-Object { $_.FullName }

# Remove existing zip if present
if (Test-Path application.zip) { Remove-Item application.zip -Force }

Compress-Archive -LiteralPath $paths -DestinationPath application.zip -Force

if (Test-Path application.zip) {
    Write-Output 'ZIP_CREATED'
    Get-Item application.zip | Format-List Name,Length,LastWriteTime
    Write-Output 'Top-level entries included:'
    Expand-Archive -LiteralPath application.zip -DestinationPath .\_tmp_appzip -Force
    Get-ChildItem -Path .\_tmp_appzip -Force | Select-Object Name,Mode
    Remove-Item -Path .\_tmp_appzip -Recurse -Force
} else {
    Write-Output 'ZIP_FAILED'
}
