This repository is prepared for AWS Elastic Beanstalk deployment.

What I added:
- `server.js` - launches the Express app exported by `index.js`.
- `Procfile` - declares the web process: `web: node server.js`.
- Updated `package.json` `start` script to `node server.js`.

How to create `application.zip` (PowerShell commands):

1. From the project root run (this excludes node_modules and .env):

```powershell
# Remove any previous zip
Remove-Item -Path application.zip -ErrorAction SilentlyContinue

# Create the zip excluding node_modules and .env
$exclude = @('node_modules','application.zip','.env','.vercel','.git')

# Use Compress-Archive (PowerShell 5.1+)
Get-ChildItem -Path . -Force | Where-Object { $exclude -notcontains $_.Name } | Compress-Archive -DestinationPath application.zip -Force
```

2. Confirm the zip contains the project files (including build folder if present):

```powershell
Expand-Archive -Path application.zip -DestinationPath .\_tmp_extract -Force
Get-ChildItem .\_tmp_extract | Select-Object Name
Remove-Item -Path .\_tmp_extract -Recurse -Force
```

3. Upload `application.zip` to Elastic Beanstalk console (Upload and deploy).

Notes:
- Ensure your EB environment has the required environment variables set (MONGO_URI, CLOUDINARY_*, JWT secrets, etc.).
- Port: EB maps the web process to port 8081/8080 internally, but your app listens on process.env.PORT. EB will set PORT; keep default fallback to 5000.
- If you need the app to always listen on 5000 specifically, configure the EB environment to set PORT=5000 (not generally required).

If you want, I can create the `application.zip` here (zipping all repo files). Tell me to proceed and I will create it, including the `build` folder if present.
